programTitle_map = new Map([

    ["Program1_Detect", "Program1 설치여부"],
    ["Program2_Detect", "Program2 설치여부"],
    ["Program3_Detect", "Program3 설치여부"],
    ["Program4_Detect", "Program4 설치여부"],
    ["Program5_Detect", "Program5 설치여부"],
    ["Program6_Detect", "Program6 설치여부"],
    ["Program7_Detect", "Program7 설치여부"],
    ["Program8_Detect", "Program8 설치여부"],
    ["Program11_Detect", "Program11 설치여부"],
    ["Game_Detect", "마이크로소프트 게임 활성화 여부"],
    ["Program10_Detect", "Program10 설치여부"],
    ["Program9_1_Detect", "Program9_1 설치여부"],
    ["Program9_2_Detect", "Program9_2 설치여부"],
    ["Current_Program1_Version", "Program1 최신버전 설치"],
    ["Current_Program2_Version", "Program2 최신버전 설치"],
    ["Current_Program3_Version", "Program3 최신버전 설치"],
    ["Current_Program4_Version", "Program4 최신버전 설치"],
    ["Current_Program5_Version", "Program5 최신버전 설치"],
    ["Current_Program6_Version", "Program6 최신버전 설치"],
    ["Current_Program7_Version", "Program7 최신버전 설치"],
    ["Current_Program8_Version", "Program8 최신버전 설치"],
    ["Current_Program9_2_Version", "Program9_2 최신버전 업데이트"]

]);

function programIsNotInstall(input){
	$("#program_secure_body").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎'+programTitle_map.get(input)+' : </a><a id="red">미설치</a></p>');
}

function programIsNotCurrentVersion(input){
	$("#program_secure_body").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎'+programTitle_map.get(input)+' : </a><a id="red">미흡</a></p>');
}

$(document).ready(function(){
    console.log(Program_result);
	Program_result = Program_result.split('\n').map((s) => s.trim()).filter((s) => s != "");

	let program_check_result_map = new Map();
	let Fix_Program = 0;


	for(i=0;i<Program_result.length;i++){
		tmp = Program_result[i].split(" ");
		program_check_result_map.set(tmp[0], tmp[1]);
	}

//탁스 설치여부, 버전 확인
	if(program_check_result_map.get("Program1_Detect") == "0x0"){
		programIsNotInstall("Program1_Detect");
        Fix_Program += 1;
	}else if(program_check_result_map.get("Current_Program1_Version") == "0x0"){
		programIsNotCurrentVersion("Current_Program1_Version");
		Fix_Program += 1;
	}
	
//탁스 내부 프로그램 설치여부, 버전 확인
	if(program_check_result_map.get("Program1_Detect") == "0x1"){
		if(program_check_result_map.get("Program3_Detect") == "0x0"){
			programIsNotInstall("Program3_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program3_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program3_Version");
			Fix_Program += 1;
		}
		
		if(program_check_result_map.get("Program4_Detect") == "0x0"){
			programIsNotInstall("Program4_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program4_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program4_Version");
			Fix_Program += 1;
		}
		
		if(program_check_result_map.get("Program5_Detect") == "0x0"){
			programIsNotInstall("Program5_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program5_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program5_Version");
			Fix_Program += 1;
		}
		
		if(program_check_result_map.get("Program6_Detect") == "0x0"){
			programIsNotInstall("Program6_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program6_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program6_Version");
			Fix_Program += 1;
		}
		
		if(program_check_result_map.get("Program7_Detect") == "0x0"){
			programIsNotInstall("Program7_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program7_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program7_Version");
			Fix_Program += 1;
		}
		
		if(program_check_result_map.get("Program3_Detect") == "0x0"){
			programIsNotInstall("Program3_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Program3") == "0x0"){
			programIsNotCurrentVersion("Program3");
			Fix_Program += 1;
		}
	}
	
//Program2 설치 및 버전 확인
	if(program_check_result_map.get("Program2_Detect") == "0x0"){
			programIsNotInstall("Program2_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program2_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program2_Version");
			Fix_Program += 1;
	}
		
//Program18 설치 및 버전 확인
	if(program_check_result_map.get("Program8_Detect") == "0x0"){
			programIsNotInstall("Program8_Detect");
			Fix_Program += 1;
		} else if(program_check_result_map.get("Current_Program8_Version") == "0x0"){
			programIsNotCurrentVersion("Current_Program8_Version");
			Fix_Program += 1;
	}
	
//Program11 설치 여부
	if(program_check_result_map.get("Program11_Detect") == "0x1"){
			$("#program_secure_body").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">Program11 설치여부 : </a><a id="red">미흡(불필요 SW로 인한 삭제 필요)</a></p>');
			Fix_Program += 1;
	}

//윈도우 기본 게임 활성화 여부
	if(program_check_result_map.get("Game_Detect") == "0x1"){
			$("#program_secure_body").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">마이크로소프트 게임 활성화 해제여부 : </a><a id="red">미흡</a></p>');
			Fix_Program += 1;
	}

//Program9_1, Program9_2 버전 및 설치 여부 확인
	if(program_check_result_map.get("Program9_1_Detect") == "0x0"){
			programIsNotInstall("Program9_1_Detect");
			Fix_Program += 1;
	} else if (program_check_result_map.get("Program9_2_Detect") == "0x0") {
        	programIsNotInstall("Program9_2_Detect");
			Fix_Program += 1;
	} else if(program_check_result_map.get("Program9_2_Version") == "0x0"){
			programIsNotCurrentVersion("Program9_2_Version");
			Fix_Program += 1;
	}
	
//Program10 설치 여부 확인
	if(program_check_result_map.get("Program10_Detect") == "0x0"){
			programIsNotInstall("Program10_Detect");
			Fix_Program += 1;
	}

	if(Fix_Program == 0){
		$("#program_secure_body").append('<br><p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎ 모든 필수 SW가 최신 버전입니다.</a></p>');
	}
	
});




