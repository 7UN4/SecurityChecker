let Program_result = `
Program1_Detect 0x0
Program2_Detect 0x0
Program3_Detect 0x0
Program4_Detect 0x0
user_Program5_Version 0x0
Program6_Detect 0x0
Program7_Detect 0x0
Program8_Detect 0x0 
Program9_1 0x0 
user_Program9_2_Detect 0x0 
Program10_Detect 0x0 
Program11_Detect 0x0
Game_Detect 0x0
`
