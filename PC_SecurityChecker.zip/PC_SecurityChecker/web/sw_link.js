sw_map = new Map([
["Program1","https://Program1.com"], 
["Program9","https://Program2.com"],
["Total_Program_Download1", "https://Total_Program_Download1.com"],
["Total_Program_Download2", "https://Total_Program_Download2.com"]
]);



$(document).ready(function(){
	
	//Program1
	$("#SW_DIV").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎ Program1 설치 페이지 : </a><a  href="'+sw_map.get("Program1")+'" style="font-weight: bold" target="_blank">링크 클릭</a></p>');
	
	//Program9
	$("#SW_DIV").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎ Program9 설치 페이지 : </a><a  href="'+sw_map.get("Program9")+'" style="font-weight: bold" target="_blank">링크 클릭</a></p>');
	
	//Total_Program_Download1
	$("#SW_DIV").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎ 프로그램 통합 설치 페이지1 : </a><a  href="'+sw_map.get("Total_Program_Download1")+'" style="font-weight: bold" target="_blank">링크 클릭</a></p>');
	
	//Total_Program_Download2
	$("#SW_DIV").append('<p class="card-text" style="font-size:17;"><a style="font-weight: bold">◎ 프로그램 통합 설치 페이지2 : </a><a  href="'+sw_map.get("Total_Program_Download2")+'" style="font-weight: bold" target="_blank">링크 클릭</a></p>');
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:17; text-align: center; "><a style="font-weight: bold; color: red">※ 일부 설정은 재부팅 후 적용되므로, 금일 퇴근 시 재부팅 또는 컴퓨터 종료 부탁드립니다 ※</a></p>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold">1. 백신 정밀 검사 실시</a></p>'
	);
	
	$("#PASS_DIV").append(
	'<img src="./V3.png" style = "max-width : 100%; height : auto;"></img>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold">2. [PC2] PC 비밀번호 복잡도 설정</a></p>'
	);
	
	$("#PASS_DIV").append(
	'<img src="./PC2비밀번호.png" style = "max-width : 100%; height : auto"></img>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold"></a></p>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold">3. [PC15] 바이러스 백신 프로그램에서 제공하는 실시간 감시 기능 활성화</a></p>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:14;"><a style="font-weight: bold">   1) 백신 프로그램 홈 화면 우측 상단의 톱니 바퀴 클릭 후, 팝업창에서 취소 클릭</a></p>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:14;"><a style="font-weight: bold">   2) 실시간 검사 체크박스 미선택 시 사이버방호실로 문의</a></p>'
	);
	
	$("#PASS_DIV").append(
	'<img src="./PC15실시간검사.png" style = "max-width : 100%; height : auto"></img>'
	);
	
	$("#PASS_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold"></a></p>'
	);
	
	$("#MADE_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold">1. v1.0.0 : 21년도 근무자</a></p>'
	);
		$("#MADE_DIV").append(
	'<p class="card-text" style="font-size:14;"><a style="font-weight: bold">  - 프로그램 최초 제작</a></p>'
	);
	
	
	$("#MADE_DIV").append(
	'<p class="card-text" style="font-size:17;"><a style="font-weight: bold">2. v2.0.0 : 대위 양진수, 상병 김동언(23.1.10)</a></p>'
	);
	
	$("#MADE_DIV").append(
	'<p class="card-text" style="font-size:14;"><a style="font-weight: bold">  - 비인가 SW 삭제, 사.보.날 체크리스트 항목 반영</a></p>'
	);
	
	$("#MADE_DIV").append(
	'<p class="card-text" style="font-size:14;"><a style="font-weight: bold">  - 23년 취약점 분석 평가 실무지침서 내용 최신화 반영</a></p>'
	);
});


